const projects = [{
        name: "websocket_server_SdaDH",
        memory: "155.34MB",
        tags: ["Web","Python","JavaScript", "API"],
        description: "远程websocket连接",
        link: "https://www.123912.com/s/Xro0Vv-nbr5d"
    },
    {
        name: "全动态教程",
        memory: "84.71KB",
        tags: ["iapp", "v3"],
        description: "动画集合",
        link: "https://www.123912.com/s/Xro0Vv-2br5d"
    }
];
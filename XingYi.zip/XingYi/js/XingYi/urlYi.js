const footerLinksData = [{
        name: "嘿哗-云",
        url: "https://cloud.mhjz1.cn/"
    },
    {
        name: "苦力怕论坛",
        url: "https://klpbbs.com/"
    },
    {
        name: "简源",
        url: "http://jane.xingyige.cn/"
    },
    {
        name: "minecraft wiki",
        url: "https://zh.minecraft.wiki/"
    },
    {
        name: "甘城なつき/Nachoneko",
        url: "https://amashiro.com/profile/"
    },
    {
        name: "赞助感谢列表 - 呆毛飘啊飘",
        url: "https://dmpap666.wodemo.net/"
    },
    {
        name: "YuChen底包|YuChenBBS",
        url: "https://bbs.yuchen.icu/index.php"
    },
    {
        name: "饼盒",
        url: "http://mc.xzwmc.com/"
    },
    {
        name: "绿叶学习网",
        url: "http://www.lvyestudy.com/"
    },
    {
        name: "菜鸟教程",
        url: "https://www.runoob.com/"
    }
];
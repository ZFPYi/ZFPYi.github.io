const careers = [{
        name: "iapp.v3",
        progress: 45
    },
    {
        name: "UI/UX设计",
        progress: 55
    },
    {
        name: "前端开发",
        progress: 47
    },
    {
        name: "后端开发",
        progress: 38
    },
    {
        name: "剪辑视频",
        progress: 43
    },
    {
        name: "汽修修理",
        progress: 25
    },
    {
        name: "lua",
        progress: 38
    },
    {
        name: "java",
        progress: 39
    },
    {
        name: "C++",
        progress: 35
    },
    {
        name: "绘画作品",
        progress: 25
    }
];
const apps = [{
        icon: "star Kai/star Kai.png",
        img: "star Kai/2025-10-12_15;19;26_com.starKai.XingYi.Minecraft.png",
        name: "star Kai",
        version: "0.1.6",
        memory: "6.26MB",
        description: "json整合",
        link: "https://www.123912.com/s/Xro0Vv-Xbr5d"
    }
];
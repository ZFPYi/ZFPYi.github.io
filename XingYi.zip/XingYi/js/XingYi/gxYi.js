const thanks = [{
        name: "XingYi",
        qq: "3529506067",
        description: "牛马人物.",
        useQQAvatar: true
    },
    {
        name: "呆毛",
        qq: "2171802813",
        description: "呆毛大佬，贡献公开开源 与 帮助解决问题.",
        useQQAvatar: true
    },
    {
        name: "耀世",
        qq: "58535045",
        description: "耀世大佬，帮助解决问题 与 售后服务好.",
        useQQAvatar: true
    },
    {
        name: "赤呆",
        qq: "2958353845",
        description: "赤呆大佬，乐于帮助 与 帮助解决问题.",
        useQQAvatar: true
    },
    {
        name: "九詺",
        qq: "2958613932",
        description: "九詺大佬，帮助解决问题 与 提供帮助开发.",
        useQQAvatar: true
    },
    {
        name: "LianYi",
        qq: "1522315829",
        description: "LianYi大佬，帮助解决问题.",
        useQQAvatar: true
    },
    {
        name: "挽风",
        qq: "2760449407",
        description: "挽风大佬，帮助解决问题.",
        useQQAvatar: true
    },
    {
        name: "許徹",
        qq: "161950189",
        description: "許徹大佬，提供解决问题 与 提供帮助开发.",
        useQQAvatar: true
    },
    {
        name: "竹林",
        qq: "2791890016",
        description: "竹林，嘿华官方、提供帮助 与 售后服务.",
        useQQAvatar: true
    },
    {
        name: "M397749490",
        qq: "397749490",
        description: "苦力怕论坛，公开下载Minecraft_Api.",
        useQQAvatar: true
    },
    {
        name: "一块钱的糖葫芦",
        qq: "1564929712",
        description: "一块钱的糖葫芦，2b2t幸运星组织玩家.",
        useQQAvatar: true
    },
    {
        name: "傀儡·戏命师NV",
        qq: "3615646167",
        description: "傀儡·戏命师，提供帮助NV文件.",
        useQQAvatar: true
    },
    {
        name: "素颜",
        qq: "836721503",
        description: "素颜大佬，提供Api帮助.",
        useQQAvatar: true
    },
    {
        name: "沐晨",
        qq: "389237694",
        description: "沐晨大佬，提供文件帮助.",
        useQQAvatar: true
    },
    {
        name: "木龙🐉",
        qq: "1797395648",
        description: "木龙大佬，提供客户端文件.",
        useQQAvatar: true
    },
    {
        name: "苏乾",
        qq: "1786107689",
        description: "苏乾大佬，自做 与 提供母牛外挂.",
        useQQAvatar: true
    },
    {
        name: "沈一岁",
        qq: "2026972130",
        description: "沈一岁大佬，自做母牛外挂",
        useQQAvatar: true
    },
    {
        name: "天月",
        qq: "3467517769",
        description: "天月大佬，自做 与 提供母牛外挂",
        useQQAvatar: true
    },
    {
        name: "唐津哲",
        qq: "3871927815",
        description: "安京大佬，开户籍 与 提供户籍思路.",
        useQQAvatar: true
    },
    {
        name: "浙江",
        qq: "3688891862",
        description: "浙江大佬，开户籍 与 提供户籍思路.",
        useQQAvatar: true
    },
    {
        name: "宿迁PLC",
        qq: "",
        description: "唐伯虎大佬，开户籍 与 提供户籍思路.",
        useQQAvatar: false,
        avatar: "http://gips0.baidu.com/it/u=172315141,3900585492&fm=3033&app=3033&f=PNG?w=272&h=272.png"
    },
    {
        name: "𝙠𝙪𝙣",
        qq: "2351116256",
        description: "𝙠𝙪𝙣大佬，售卖纯客户端、客户端外挂 与 提供文件渠道、帮助.",
        useQQAvatar: true,
        avatar: "https://via.placeholder.com/100?text=技术"
    }
];
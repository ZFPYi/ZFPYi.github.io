// 赞助者数据
const sponsors = [{
        name: "kzlo",
        amount: 188.88,
        qq: "3833396947",
        wechat: "",
        avatar: true
    },
    {
        name: "小菜包",
        amount: 214.81,
        qq: "3383850594",
        wechat: "",
        avatar: true,
        avatarUrl: ""
    }
];
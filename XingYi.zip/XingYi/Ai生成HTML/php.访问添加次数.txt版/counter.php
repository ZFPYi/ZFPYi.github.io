<?php
$counterFile = "counter.txt"; // 定义存储计数器的文本文件

// 检查文件是否存在，如果不存在则创建并初始化为0
if (!file_exists($counterFile)) {
    file_put_contents($counterFile, 0);
}

// 读取文件中的计数器值
$counter = file_get_contents($counterFile);

// 将计数器的值转换为整数
$counter = (int)$counter;

// 每次页面加载时，增加计数器的值
$counter += 1;

// 检查计数器的值是否达到1000000，如果是，则重置为0
if ($counter >= 1000000) {
    $counter = 0;
}

// 将新的计数器值写回文件
file_put_contents($counterFile, $counter);

// 返回新的计数器值
echo $counter;
?>
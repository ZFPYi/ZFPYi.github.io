<?php

$filename = "./18r.txt";
if (!file_exists($filename)) {
    http_response_code(404);
    die('文件不存在');
}

$pics = [];
$fs = fopen($filename, "r");
if ($fs === false) {
    http_response_code(500);
    die('无法打开文件');
}

while (!feof($fs)) {
    $line = trim(fgets($fs));
    if ($line !== '') {
        array_push($pics, $line);
    }
}

if (empty($pics)) {
    http_response_code(204);
    die('没有可用的链接');
}

$pic = $pics[array_rand($pics)];

// 使用 file_get_contents("php://input") 从 POST 请求中获取数据
$postData = file_get_contents("php://input");
$type = json_decode($postData, true);

if (isset($type['type'])) {
    $type = $type['type'];
} else {
    $type = 'txt'; // 默认为 txt 响应
}

header('Content-Type: text/plain'); // 设置响应类型为纯文本

switch ($type) {
    case 'txt':
        echo $pic;
        break;
    default:
        // 如果需要，可以在这里添加其他类型的处理逻辑
        break;
}
?>